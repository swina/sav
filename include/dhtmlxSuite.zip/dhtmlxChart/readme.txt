dhtmlxChart v.2.6.5 Standard edition build 101011

(c) DHTMLX Ltd. 