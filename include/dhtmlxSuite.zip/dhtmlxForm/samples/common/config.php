<?php

$mysql_host = "db2.dhtmlx.com";
$mysql_user = "dhtmuzer_ro";
$mysql_pasw = "gp45_gm";
$mysql_db   = "dhtmlxsamples";
    
$conn = mysql_connect($mysql_host,$mysql_user,$mysql_pasw);
mysql_select_db($mysql_db);


?>